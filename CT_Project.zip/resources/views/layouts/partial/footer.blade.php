<center>
    copyright © 2019, <a href="https://www.samiu.me" target="_blank" style="color: darkslateblue;"><b>Sammy</b></a>. All right reserved.
</center>
