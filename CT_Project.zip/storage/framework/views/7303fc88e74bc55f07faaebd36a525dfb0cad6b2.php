<!DOCTYPE html>
<html lang="en">
<head>
    <title>Show Credential</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>

<body style="margin-top: 50px">

<div class="container">
    <table width="100%">
        <?php if(Auth::user()->role == 'Admin'): ?>
            <tr>
                <td align="center">
                    <button type="button" class="btn btn-success">
                        <a href="<?php echo e(route('user.dashboard')); ?>" style="color: whitesmoke"><strong>Dashboard</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-primary">
                        <a href="<?php echo e(route('admin.show')); ?>" style="color: whitesmoke"><strong>Show User</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-warning">
                        <a href="<?php echo e(route('user.addcredentials')); ?>" style="color: black"><strong>Add Credential</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-info">
                        <a href="<?php echo e(route('user.showcredentials')); ?>" style="color: whitesmoke"><strong>Show Credentials</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-dark">
                        <a href="<?php echo e(route('user.account')); ?>" style="color: whitesmoke"><strong>View Account</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-danger">
                        <a href="<?php echo e(route('user.logout')); ?>" style="color: whitesmoke"><strong>Logout</strong></a>
                    </button>
                </td>
            </tr>
        <?php else: ?>
            <tr>
                <td align="center">
                    <button type="button" class="btn btn-success">
                        <a href="<?php echo e(route('user.dashboard')); ?>" style="color: whitesmoke"><strong>Dashboard</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-warning">
                        <a href="<?php echo e(route('user.addcredentials')); ?>" style="color: black"><strong>Add Credential</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-info">
                        <a href="<?php echo e(route('user.showcredentials')); ?>" style="color: whitesmoke"><strong>Show Credentials</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-dark">
                        <a href="<?php echo e(route('user.account')); ?>" style="color: whitesmoke"><strong>View Account</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-danger">
                        <a href="<?php echo e(route('user.logout')); ?>" style="color: whitesmoke"><strong>Logout</strong></a>
                    </button>
                </td>
            </tr>
        <?php endif; ?>
    </table>

    <hr>
    <h2 align="center">Your Credential Dashboard</h2>
    <table class="table table-hover">
        <thead>
        <tr>
            <th>Title</th>
            <th>URL</th>
            <th>Username</th>
            <th>Email</th>
            <th>Password</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cred): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <?php echo e($cred->title); ?> </td>
                <td> <?php echo e($cred->url); ?> </td>
                <td> <?php echo e($cred->user); ?> </td>
                <td> <?php echo e($cred->email); ?> </td>
                <td> <?php echo e($cred->password); ?> </td>
                <td>
                    <button type="button" class="btn btn-outline-info btn-sm">
                        <a href="<?php echo e(route('user.cred.edit',[$cred->id])); ?>"><b>Edit</b></a>
                    </button>
                    <button type="button" class="btn btn-outline-danger btn-sm">
                        <a href="<?php echo e(route('user.cred.delete',[$cred->id])); ?>" style="color: darkred"><b>Delete</b></a>
                    </button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($information->links()); ?>

</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\project_v2\resources\views/user/showcred.blade.php ENDPATH**/ ?>