<html>
<head>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body style="margin-top: 100px; background-color: #9561e2"><center>
    <h1>Update Credential</h1>
    <form action="<?php echo e(route('user.cred.update',[$cred->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <input type="text" name="title" placeholder="Title" value="<?php echo e($cred->title); ?>"></br>
        <input type="text" name="url" placeholder="URL" value="<?php echo e($cred->url); ?>"></br>
        <input type="text" name="user" placeholder="Username" value="<?php echo e($cred->user); ?>"></br>
        <input type="email" name="email" placeholder="Email" value="<?php echo e($cred->email); ?>"></br>
        <input type="password" name="password" placeholder="Password" value="<?php echo e($cred->password); ?>"></br>
        <input type="submit" name="submit" value="Update">
    </form></center>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\project_v2\resources\views/user/edit-credential.blade.php ENDPATH**/ ?>