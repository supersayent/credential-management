<?php $__env->startSection('content'); ?>
    <table width="100%">
        <?php if(Auth::user()->role == 'Admin'): ?>
            <tr>
                <td align="center">
                    <button type="button" class="btn btn-success">
                        <a href="<?php echo e(route('user.dashboard')); ?>" style="color: whitesmoke"><strong>Dashboard</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-primary">
                        <a href="<?php echo e(route('admin.show')); ?>" style="color: whitesmoke"><strong>Show User</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-warning">
                        <a href="<?php echo e(route('user.addcredentials')); ?>" style="color: black"><strong>Add Credential</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-info">
                        <a href="<?php echo e(route('user.showcredentials')); ?>" style="color: whitesmoke"><strong>Show Credentials</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-dark">
                        <a href="<?php echo e(route('user.account')); ?>" style="color: whitesmoke"><strong>View Account</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-danger">
                        <a href="<?php echo e(route('user.logout')); ?>" style="color: whitesmoke"><strong>Logout</strong></a>
                    </button>
                </td>
            </tr>
        <?php else: ?>
            <tr>
                <td align="center">
                    <button type="button" class="btn btn-success">
                        <a href="<?php echo e(route('user.dashboard')); ?>" style="color: whitesmoke"><strong>Dashboard</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-warning">
                        <a href="<?php echo e(route('user.addcredentials')); ?>" style="color: black"><strong>Add Credential</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-info">
                        <a href="<?php echo e(route('user.showcredentials')); ?>" style="color: whitesmoke"><strong>Show Credentials</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-dark">
                        <a href="<?php echo e(route('user.account')); ?>" style="color: whitesmoke"><strong>View Account</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-danger">
                        <a href="<?php echo e(route('user.logout')); ?>" style="color: whitesmoke"><strong>Logout</strong></a>
                    </button>
                </td>
            </tr>
        <?php endif; ?>
    </table>
    <hr>

    <form action="<?php echo e(route('user.addcredentials')); ?>" style="max-width:500px;margin:auto" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <h2 align="center"><strong>Add Credential</strong></h2>
        <hr>
        <div class="input-container">
            <i class="fa fa-address-card-o icon"></i>
            <input class="input-field" type="text" placeholder="Title" name="title" required>
        </div>

        <div class="input-container">
            <i class="fa fa-link icon"></i>
            <input class="input-field" type="url" placeholder="http://www.yoururl.com" name="url" required>
        </div>

        <div class="input-container">
            <i class="fa fa-user icon"></i>
            <input class="input-field" type="text" placeholder="Username" name="user" required>
        </div>

        <div class="input-container">
            <i class="fa fa-envelope icon"></i>
            <input class="input-field" type="email" placeholder="Email" name="email" required>
        </div>

        <div class="input-container">
            <i class="fa fa-key icon"></i>
            <input class="input-field" type="password" placeholder="Password" name="password" required>
        </div>

        <button type="submit" class="btn btn-success"><b>Add</b></button>
    </form>
    <br><hr>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-cred', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_v2\resources\views/user/credentials.blade.php ENDPATH**/ ?>