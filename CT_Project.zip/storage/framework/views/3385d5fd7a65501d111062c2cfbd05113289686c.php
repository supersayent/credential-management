<?php $__env->startSection('content'); ?>
    <section class="stage" style="margin-top: 200px">
        <div id="register" class="div">
            <p id="homep" class="p" onclick="document.getElementById('id01').style.display='block'" style="width:auto;">
                Register
            </p>
        </div>

        <div id="login" class="div">
            <p class="p" onclick="document.getElementById('id02').style.display='block'" style="width:auto;">
                Login
            </p>
        </div>

        <div id="contact" class="div">
            <p class="p">Contact</p>
        </div>

        <div id="owner" class="div">
            <p class="p">Owner</p>
        </div>
    </section>

    <?php echo $__env->make('user.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_v2\resources\views/home.blade.php ENDPATH**/ ?>