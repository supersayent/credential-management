<?php $__env->startSection('content'); ?>
    <div class="main">
        <p>Welcome <b><?php echo e(Auth::user()->role); ?>, <?php echo e(Auth::user()->name); ?></b> to your dashboard.</p>
        <div class="side">
            <nav class="dr-menu">
                <div class="dr-trigger"><span class="dr-icon dr-icon-menu"></span><a class="dr-label">Account</a></div>
                <ul>
                    

                <?php if(Auth::user()->role == 'Admin'): ?>
                    <li><a class="dr-icon dr-icon-user" href="<?php echo e(route('user.dashboard')); ?>"><?php echo e(Auth::user()->name); ?></a></li>
                    <li><a class="dr-icon dr-icon-bullhorn" href="<?php echo e(route('admin.show')); ?>">View User</a></li>
                    <li><a class="dr-icon dr-icon-download" href="<?php echo e(route('user.addcredentials')); ?>">Add Credential</a></li>
                    <li><a class="dr-icon dr-icon-bullhorn" href="<?php echo e(route('user.showcredentials')); ?>">Show Credentials</a></li>
                    <li><a class="dr-icon dr-icon-settings" href="<?php echo e(route('user.account')); ?>">Edit Account</a></li>
                    <li><a class="dr-icon dr-icon-switch" href="<?php echo e(route('user.logout')); ?>">Logout</a></li>
                <?php else: ?>
                    <li><a class="dr-icon dr-icon-user" href="<?php echo e(route('user.dashboard')); ?>"><?php echo e(Auth::user()->name); ?></a></li>
                    <li><a class="dr-icon dr-icon-download" href="<?php echo e(route('user.addcredentials')); ?>">Add Credential</a></li>
                    <li><a class="dr-icon dr-icon-bullhorn" href="<?php echo e(route('user.showcredentials')); ?>">Show Credentials</a></li>
                    <li><a class="dr-icon dr-icon-settings" href="<?php echo e(route('user.account')); ?>">Edit Account</a></li>
                    <li><a class="dr-icon dr-icon-switch" href="<?php echo e(route('user.logout')); ?>">Logout</a></li>
                <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>

    <script src="js/ytmenu.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_v2\resources\views/user/dashboard.blade.php ENDPATH**/ ?>