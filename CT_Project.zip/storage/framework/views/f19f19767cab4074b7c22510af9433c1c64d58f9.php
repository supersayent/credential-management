<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>

<body style="margin-top: 50px">

<div class="container">
    <table width="100%">
        <?php if(Auth::user()->role == 'Admin'): ?>
            <tr>
                <td align="center">
                    <button type="button" class="btn btn-success">
                        <a href="<?php echo e(route('user.dashboard')); ?>" style="color: whitesmoke"><strong>Dashboard</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-primary">
                        <a href="<?php echo e(route('admin.show')); ?>" style="color: whitesmoke"><strong>Show User</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-warning">
                        <a href="<?php echo e(route('user.addcredentials')); ?>" style="color: black"><strong>Add Credential</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-info">
                        <a href="<?php echo e(route('user.showcredentials')); ?>" style="color: whitesmoke"><strong>Show Credentials</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-dark">
                        <a href="<?php echo e(route('user.account')); ?>" style="color: whitesmoke"><strong>View Account</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-danger">
                        <a href="<?php echo e(route('user.logout')); ?>" style="color: whitesmoke"><strong>Logout</strong></a>
                    </button>
                </td>
            </tr>
        <?php else: ?>
            <tr>
                <td align="center">
                    <button type="button" class="btn btn-success">
                        <a href="<?php echo e(route('user.dashboard')); ?>" style="color: whitesmoke"><strong>Dashboard</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-warning">
                        <a href="<?php echo e(route('user.addcredentials')); ?>" style="color: black"><strong>Add Credential</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-info">
                        <a href="<?php echo e(route('user.showcredentials')); ?>" style="color: whitesmoke"><strong>Show Credentials</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-dark">
                        <a href="<?php echo e(route('user.account')); ?>" style="color: whitesmoke"><strong>View Account</strong></a>
                    </button>
                </td>
                <td align="center">
                    <button type="button" class="btn btn-danger">
                        <a href="<?php echo e(route('user.logout')); ?>" style="color: whitesmoke"><strong>Logout</strong></a>
                    </button>
                </td>
            </tr>
        <?php endif; ?>
    </table>

    <hr>
    <h2 align="center">Admin Dashboard</h2>
    <table class="table table-hover">
        <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone number</th>
            <th>Role</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <?php echo e($user->id); ?> </td>
                <td> <?php echo e($user->name); ?> </td>
                <td> <?php echo e($user->email); ?> </td>
                <td> <?php echo e($user->phone); ?> </td>
                <td> <?php echo e($user->role); ?> </td>
                <td> <?php echo e($user->status); ?> </td>
                <td>
                    <button type="button" class="btn btn-outline-info btn-sm">
                        <a href="<?php echo e(route('user.edit',[$user->id])); ?>"><b>Edit</b></a>
                    </button>
                </td>
                
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\project_v2\resources\views/admin/admindash.blade.php ENDPATH**/ ?>